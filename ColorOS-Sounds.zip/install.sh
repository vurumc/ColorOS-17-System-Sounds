#!/sbin/sh

SKIPUNZIP=1
SKIPMOUNT=0
MODPROP="${MODPATH}/module.prop"

unzip -qo "$ZIPFILE" "module.prop" -d "$MODPATH" 2>/dev/null
NAME=$(grep -E '^name=' "$MODPROP" | cut -d'=' -f2)
AUTHOR=$(grep -E '^author=' "$MODPROP" | cut -d'=' -f2)
VERSION=$(grep -E '^version=' "$MODPROP" | cut -d'=' -f2)
   
ui_print "**************************"
ui_print " $NAME"
ui_print " by $AUTHOR"
ui_print " Версия: $VERSION"
ui_print "**************************"

ui_print "- [🗂️] Unpacking ColorOS 17 Sounds..."
    unzip -qo "$ZIPFILE" "system/*" -d "$MODPATH" 2>/dev/null       
        
ui_print "- [🎉] Replacing System Sounds..."
    set_perm_recursive "$MODPATH" 0 0 0755 0644